package com.rpg.FireEmblem;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FireEmblemApplicationTests {

	@Test
	void contextLoads() {
	}

}
