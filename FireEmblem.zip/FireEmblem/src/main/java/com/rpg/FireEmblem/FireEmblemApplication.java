package com.rpg.FireEmblem;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FireEmblemApplication {

	public static void main(String[] args) {
		SpringApplication.run(FireEmblemApplication.class, args);
	}

}
